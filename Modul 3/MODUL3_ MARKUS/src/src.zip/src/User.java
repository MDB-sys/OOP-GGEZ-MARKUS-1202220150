public class User {
   
   
   // TO DO: Create Private Attributes of User (nama, noHandphone)
   
   // TO DO: Create Constructor of User
   
   public void setName(String nama) {
         
      }

   public void setNoHandPhone(String phoneNumber) {
      }
   // TO DO: Create register Method to show information about name and phone number
   public void register(){
        
    }
   // TO DO: Create method to return name and phone number
   
   public String getName() {
     
  }

   public String getnoHandPhone() {
     
  }
}






  