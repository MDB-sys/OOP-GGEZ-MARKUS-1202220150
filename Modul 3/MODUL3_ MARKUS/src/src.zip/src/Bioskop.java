public class Bioskop {
    
    // TO DO: Create Private Attributes of rows and assign rows to 5
    
    // TO DO: Create Private Attributes of seats per rows and assign seats per rows to 10
    
    // TO DO: Create 2 dimensional array to store seat reservation status
    
    // TO DO:  Add a constructor to initialize multiple chairs
    public Bioskop() {
       
    }
    //  TO DO: Add a method to display the seat layout
    public void displaySeating() {

    }
    //  TO DO: Add a method to reserve seats
    public void bookSeat(int row, int seat) {
        
    }
}