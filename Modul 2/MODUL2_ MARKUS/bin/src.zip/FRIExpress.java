public class FRIExpress //...
{
    // TO DO: Create Protected Attribute of FRIExpress (pecahBelah)

    // TO DO: Create Constructor of FRIExpress

    // TO DO: Create 'informasi' Method to show Information

    // TO DO: Create 'terima' Method to accept a number of packages

    // TO DO: Create 'kirim' Method to send a package to a destination

    // TO DO: Create 'kirim' Method to send a package to two destinations
}
