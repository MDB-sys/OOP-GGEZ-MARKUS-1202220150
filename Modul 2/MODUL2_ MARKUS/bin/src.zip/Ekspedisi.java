public class Ekspedisi 
{
    // TO DO: Create Protected Attributes of Ekspedisi (jumlahCabang, pusat, tarif)

    // TO DO: Create Constructor of Ekspedisi

    // TO DO: Create 'informasi' Method to show Information
}
