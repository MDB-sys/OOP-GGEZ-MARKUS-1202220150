public class MainApp {
    public static void main(String[] args){
        
        // TO DO: Create expedisi Object from Ekspedisi Class

        // TO DO: Create teluexpress Object from TelUExpress Class

        // TO DO: Create friexpress Object from FRIExpress Class


    }
}
