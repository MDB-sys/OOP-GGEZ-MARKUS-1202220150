public class TelUExpress //...
{
    // TO DO: Create Protected Atribute of TelUExpress(antarInter)

    // TO DO: Create Constructor of TelUExpress

    // TO DO: Create 'informasi' Method to show Information

    // TO DO: Create 'ambil' Method to pick up a package

    // TO DO: Create 'antar' Method to send a package

    // TO DO: Create 'antar' Method to send two packages
}
